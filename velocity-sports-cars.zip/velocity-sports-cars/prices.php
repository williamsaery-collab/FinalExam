<?php
require __DIR__ . '/includes/db.php';

$pageTitle = 'Selling Prices';
$pdo = getDatabaseConnection();

$search = trim($_GET['search'] ?? '');
$editId = isset($_GET['edit_id']) ? (int) $_GET['edit_id'] : 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'save_price') {
        $id = (int) ($_POST['id'] ?? 0);
        $carId = (int) ($_POST['car_id'] ?? 0);
        $priceAmount = (float) ($_POST['price_amount'] ?? 0);
        $currency = trim($_POST['currency'] ?? 'PHP');
        $priceDate = $_POST['price_date'] ?? date('Y-m-d');

        if ($carId <= 0 || $priceAmount <= 0) {
            setFlash('Please provide a valid price and car selection.', 'error');
            redirect('prices.php');
        }

        if ($id > 0) {
            $stmt = $pdo->prepare('UPDATE prices SET car_id = :car_id, price_amount = :price_amount, currency = :currency, price_date = :price_date WHERE id = :id');
            $stmt->execute([
                ':car_id' => $carId,
                ':price_amount' => $priceAmount,
                ':currency' => $currency,
                ':price_date' => $priceDate,
                ':id' => $id,
            ]);
            setFlash('Price updated successfully.');
        } else {
            $stmt = $pdo->prepare('INSERT INTO prices (car_id, price_amount, currency, price_date) VALUES (:car_id, :price_amount, :currency, :price_date)');
            $stmt->execute([
                ':car_id' => $carId,
                ':price_amount' => $priceAmount,
                ':currency' => $currency,
                ':price_date' => $priceDate,
            ]);
            setFlash('Price added successfully.');
        }

        redirect('prices.php');
    }

    if ($action === 'delete_price') {
        $id = (int) ($_POST['id'] ?? 0);
        if ($id > 0) {
            $pdo->prepare('DELETE FROM prices WHERE id = :id')->execute([':id' => $id]);
            setFlash('Price deleted successfully.');
        }
        redirect('prices.php');
    }
}

$cars = $pdo->query('SELECT id, name FROM cars WHERE deleted_at IS NULL ORDER BY name ASC')->fetchAll();

$query = 'SELECT p.*, c.name AS car_name, c.image_url, c.status AS car_status FROM prices p JOIN cars c ON c.id = p.car_id';
$params = [];
if ($search !== '') {
    $query .= ' WHERE c.name LIKE :search OR c.model LIKE :search';
    $params[':search'] = '%' . $search . '%';
}
$query .= ' ORDER BY p.price_date DESC, p.id DESC';
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$prices = $stmt->fetchAll();

if ($editId > 0) {
    $editPrice = $pdo->prepare('SELECT * FROM prices WHERE id = :id');
    $editPrice->execute([':id' => $editId]);
    $editPrice = $editPrice->fetch();
}

include __DIR__ . '/includes/header.php';
?>

<div class="panel">
    <div class="panel-header">
        <div>
            <h2>Premium Sports Car Selling Prices</h2>
            <p class="panel-kicker">Manage the current selling price for every showroom vehicle.</p>
        </div>
        <button type="button" class="primary-btn" data-modal-target="price-modal">Add Selling Price</button>
    </div>

    <form method="get" class="toolbar">
        <div class="search-box">
            <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search by car name or model">
        </div>
        <button type="submit" class="secondary-btn">Apply</button>
        <a href="prices.php" class="ghost-btn">Reset</a>
    </form>

    <div class="price-grid">
        <?php if ($prices): ?>
            <?php foreach ($prices as $price): ?>
                <article class="price-card">
                    <div class="price-card-image"><?php echo renderCarThumbnail($price['image_url'] ?? '', $price['car_name'], 500, 220); ?></div>
                    <div class="price-card-body">
                        <div class="price-card-heading"><div><p class="vehicle-brand">Current offer</p><h3><?php echo htmlspecialchars($price['car_name']); ?></h3></div><span class="badge <?php echo strtolower($price['car_status'] ?? 'available'); ?>"><?php echo htmlspecialchars($price['car_status'] ?? 'Available'); ?></span></div>
                        <strong class="selling-price"><?php echo formatCurrency((float) $price['price_amount']); ?></strong>
                        <p class="price-date">Effective <?php echo htmlspecialchars($price['price_date']); ?></p>
                        <div class="action-group"><a href="cars.php?view_id=<?php echo (int) $price['car_id']; ?>" class="small-btn">View Details</a><a href="prices.php?edit_id=<?php echo (int) $price['id']; ?>" class="small-btn">Edit</a><form method="post" onsubmit="return confirm('Delete this pricing record?')"><input type="hidden" name="action" value="delete_price"><input type="hidden" name="id" value="<?php echo (int) $price['id']; ?>"><button type="submit" class="small-btn danger">Delete</button></form></div>
                    </div>
                </article>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="empty-state">No selling prices found.</div>
        <?php endif; ?>
    </div>
</div>

<div id="price-modal" class="modal <?php echo $editId > 0 ? 'open' : ''; ?>">
    <div class="modal-card">
        <div class="modal-header">
            <h3><?php echo $editId > 0 ? 'Edit Price' : 'Add Price'; ?></h3>
            <button type="button" class="modal-close">×</button>
        </div>
        <form method="post">
            <div class="modal-body">
                <input type="hidden" name="action" value="save_price">
                <input type="hidden" name="id" value="<?php echo htmlspecialchars((string) ($editPrice['id'] ?? '')); ?>">
                <div class="form-grid">
                    <div class="form-group full">
                        <label for="car_id">Car</label>
                        <select id="car_id" class="form-control" name="car_id" required>
                            <option value="">Select car</option>
                            <?php foreach ($cars as $car): ?>
                                <option value="<?php echo (int) $car['id']; ?>" <?php echo (($editPrice['car_id'] ?? 0) == $car['id']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($car['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="price_amount">Selling Price Amount</label>
                        <input id="price_amount" type="number" step="0.01" class="form-control" name="price_amount" value="<?php echo htmlspecialchars((string) ($editPrice['price_amount'] ?? '')); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="currency">Currency</label>
                        <input id="currency" type="text" class="form-control" name="currency" value="<?php echo htmlspecialchars($editPrice['currency'] ?? 'PHP'); ?>" required>
                    </div>
                    <div class="form-group full">
                        <label for="price_date">Effective Date</label>
                        <input id="price_date" type="date" class="form-control" name="price_date" value="<?php echo htmlspecialchars($editPrice['price_date'] ?? date('Y-m-d')); ?>" required>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="ghost-btn modal-close">Cancel</button>
                <button type="submit" class="primary-btn"><?php echo $editId > 0 ? 'Update Price' : 'Add Price'; ?></button>
            </div>
        </form>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
