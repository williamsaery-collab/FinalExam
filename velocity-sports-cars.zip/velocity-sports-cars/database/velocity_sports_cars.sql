CREATE DATABASE IF NOT EXISTS velocity_sports_cars;
USE velocity_sports_cars;

DROP TABLE IF EXISTS sales_transactions;
DROP TABLE IF EXISTS test_drive_bookings;
DROP TABLE IF EXISTS prices;
DROP TABLE IF EXISTS specifications;
DROP TABLE IF EXISTS cars;
DROP TABLE IF EXISTS customers;

CREATE TABLE cars (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    brand VARCHAR(100) NOT NULL,
    model VARCHAR(100) NOT NULL,
    year INT NOT NULL,
    status ENUM('Available', 'Reserved', 'Sold') NOT NULL DEFAULT 'Available',
    image_url VARCHAR(255) DEFAULT NULL,
    deleted_at DATETIME DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE specifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    car_id INT NOT NULL UNIQUE,
    horsepower INT NOT NULL,
    torque INT NOT NULL,
    top_speed_kmh INT NOT NULL,
    acceleration_0_100 INT NOT NULL,
    drivetrain VARCHAR(50) NOT NULL,
    transmission VARCHAR(50) NOT NULL,
    engine VARCHAR(100) NOT NULL,
    fuel_type VARCHAR(50) NOT NULL,
    color VARCHAR(50) NOT NULL,
    FOREIGN KEY (car_id) REFERENCES cars(id) ON DELETE CASCADE
);

CREATE TABLE prices (
    id INT AUTO_INCREMENT PRIMARY KEY,
    car_id INT NOT NULL,
    price_amount DECIMAL(12,2) NOT NULL,
    currency VARCHAR(10) NOT NULL DEFAULT 'PHP',
    price_date DATE NOT NULL,
    FOREIGN KEY (car_id) REFERENCES cars(id) ON DELETE CASCADE
);

CREATE TABLE customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(150) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    phone VARCHAR(30) NOT NULL,
    city VARCHAR(100) NOT NULL,
    preferred_model VARCHAR(100) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE test_drive_bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    car_id INT NOT NULL,
    booking_date DATE NOT NULL,
    booking_time TIME NOT NULL,
    status ENUM('Pending', 'Completed', 'Cancelled') NOT NULL DEFAULT 'Pending',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
    FOREIGN KEY (car_id) REFERENCES cars(id) ON DELETE CASCADE
);

CREATE TABLE sales_transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    car_id INT NOT NULL,
    sale_date DATE NOT NULL,
    sale_amount DECIMAL(12,2) NOT NULL,
    payment_method VARCHAR(50) NOT NULL,
    status ENUM('Paid', 'Pending', 'Refunded') NOT NULL DEFAULT 'Paid',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
    FOREIGN KEY (car_id) REFERENCES cars(id) ON DELETE CASCADE
);

INSERT INTO cars (name, brand, model, year, status, image_url) VALUES
('Ferrari 488', 'Ferrari', '488 GTB', 2024, 'Available', 'assets/images/cars/ferrari-488.jpg'),
('Lamborghini Huracán', 'Lamborghini', 'Huracán STO', 2024, 'Available', 'assets/images/cars/lamborghini-huracan.jpg'),
('Porsche 911', 'Porsche', '911 Carrera', 2023, 'Reserved', 'assets/images/cars/porsche-911GT3.jpg'),
('McLaren 720S', 'McLaren', '720S', 2024, 'Available', 'assets/images/cars/mclaren-720s.jpg'),
('Nissan GT-R', 'Nissan', 'GT-R Premium', 2023, 'Sold', 'assets/images/cars/nissan-gtrSkyline.jpg');

INSERT INTO specifications (car_id, horsepower, torque, top_speed_kmh, acceleration_0_100, drivetrain, transmission, engine, fuel_type, color) VALUES
(1, 661, 760, 330, 3.0, 'RWD', '7-speed dual-clutch', '3.9L V8 twin-turbo', 'Petrol', 'Rosso Corsa'),
(2, 631, 565, 322, 2.9, 'AWD', '7-speed dual-clutch', '5.2L V10', 'Petrol', 'Arancio Borealis'),
(3, 379, 470, 293, 3.6, 'RWD', '8-speed PDK', '3.0L twin-turbo flat-six', 'Petrol', 'GT Silver Metallic'),
(4, 710, 770, 341, 2.9, 'RWD', '7-speed dual-clutch', '4.0L twin-turbo V8', 'Petrol', 'Papaya Orange'),
(5, 565, 637, 315, 2.9, 'AWD', '6-speed dual-clutch', '3.8L twin-turbo V6', 'Petrol', 'Pearl White');

INSERT INTO prices (car_id, price_amount, currency, price_date) VALUES
(1, 12500000.00, 'PHP', '2026-09-01'),
(2, 16500000.00, 'PHP', '2026-09-01'),
(3, 10500000.00, 'PHP', '2026-09-01'),
(4, 18000000.00, 'PHP', '2026-09-01'),
(5, 8500000.00, 'PHP', '2026-09-01');

INSERT INTO customers (full_name, email, phone, city, preferred_model) VALUES
('Alden Cruz', 'alden.cruz@email.com', '+639171234567', 'Manila', 'Ferrari 488'),
('Mika Santos', 'mika.santos@email.com', '+639181112233', 'Cebu', 'Porsche 911'),
('Rafael Gomez', 'rafael.gomez@email.com', '+639195556677', 'Davao', 'Lamborghini Huracán'),
('Lia Navarro', 'lia.navarro@email.com', '+639178889900', 'Baguio', 'McLaren 720S'),
('Jasper Tan', 'jasper.tan@email.com', '+639172345678', 'Quezon City', 'Nissan GT-R');

INSERT INTO test_drive_bookings (customer_id, car_id, booking_date, booking_time, status, notes) VALUES
(1, 1, '2026-09-28', '10:30:00', 'Pending', 'Interested in a weekend test drive and financing options.'),
(2, 3, '2026-09-29', '13:00:00', 'Completed', 'Customer completed the full drive evaluation.'),
(3, 2, '2026-09-30', '15:15:00', 'Pending', 'Wants to compare Huracán with competitor models.'),
(4, 4, '2026-10-02', '09:00:00', 'Completed', 'Accepted the test drive and requested brochure pack.'),
(5, 5, '2026-10-03', '11:45:00', 'Cancelled', 'Cancelled due to schedule conflict.');

INSERT INTO sales_transactions (customer_id, car_id, sale_date, sale_amount, payment_method, status, notes) VALUES
(1, 5, '2026-08-14', 8500000.00, 'Bank Transfer', 'Paid', 'Customer purchased the GT-R on a premium package.'),
(2, 3, '2026-08-25', 10500000.00, 'Cash', 'Paid', 'Vehicle sold with full aftersales package.'),
(3, 2, '2026-09-03', 16500000.00, 'Installment', 'Pending', 'Processing customer financing approval.'),
(4, 4, '2026-09-09', 18000000.00, 'Bank Transfer', 'Paid', 'Delivery scheduled within 2 weeks.'),
(5, 1, '2026-09-15', 12500000.00, 'Cash', 'Paid', 'Immediate sale with showroom accessories included.');
