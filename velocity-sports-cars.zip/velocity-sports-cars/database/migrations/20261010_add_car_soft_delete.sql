﻿-- Safe, data-preserving migration for Deleted Items.
-- Run once in phpMyAdmin with velocity_sports_cars selected.
ALTER TABLE cars ADD COLUMN deleted_at DATETIME NULL DEFAULT NULL AFTER image_url;
