<?php
require __DIR__ . '/includes/db.php';

$pageTitle = 'Test Drives Before Purchase';
$pdo = getDatabaseConnection();

$search = trim($_GET['search'] ?? '');
$statusFilter = $_GET['status'] ?? '';
$editId = isset($_GET['edit_id']) ? (int) $_GET['edit_id'] : 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'save_booking') {
        $id = (int) ($_POST['id'] ?? 0);
        $customerId = (int) ($_POST['customer_id'] ?? 0);
        $carId = (int) ($_POST['car_id'] ?? 0);
        $bookingDate = $_POST['booking_date'] ?? date('Y-m-d');
        $bookingTime = $_POST['booking_time'] ?? '09:00';
        $status = $_POST['status'] ?? 'Pending';
        $notes = trim($_POST['notes'] ?? '');

        if ($customerId <= 0 || $carId <= 0) {
            setFlash('Please select a customer and car for the booking.', 'error');
            redirect('bookings.php');
        }

        if ($id > 0) {
            $stmt = $pdo->prepare('UPDATE test_drive_bookings SET customer_id = :customer_id, car_id = :car_id, booking_date = :booking_date, booking_time = :booking_time, status = :status, notes = :notes WHERE id = :id');
            $stmt->execute([
                ':customer_id' => $customerId,
                ':car_id' => $carId,
                ':booking_date' => $bookingDate,
                ':booking_time' => $bookingTime,
                ':status' => $status,
                ':notes' => $notes,
                ':id' => $id,
            ]);
            setFlash('Booking updated successfully.');
        } else {
            $stmt = $pdo->prepare('INSERT INTO test_drive_bookings (customer_id, car_id, booking_date, booking_time, status, notes) VALUES (:customer_id, :car_id, :booking_date, :booking_time, :status, :notes)');
            $stmt->execute([
                ':customer_id' => $customerId,
                ':car_id' => $carId,
                ':booking_date' => $bookingDate,
                ':booking_time' => $bookingTime,
                ':status' => $status,
                ':notes' => $notes,
            ]);
            setFlash('Booking created successfully.');
        }

        redirect('bookings.php');
    }

    if ($action === 'delete_booking') {
        $id = (int) ($_POST['id'] ?? 0);
        if ($id > 0) {
            $pdo->prepare('DELETE FROM test_drive_bookings WHERE id = :id')->execute([':id' => $id]);
            setFlash('Booking deleted successfully.');
        }
        redirect('bookings.php');
    }
}

$customers = $pdo->query('SELECT id, full_name FROM customers ORDER BY full_name ASC')->fetchAll();
$cars = $pdo->query('SELECT id, name FROM cars WHERE deleted_at IS NULL ORDER BY name ASC')->fetchAll();

$query = 'SELECT tb.*, c.full_name AS customer_name, car.name AS car_name, car.image_url FROM test_drive_bookings tb JOIN customers c ON c.id = tb.customer_id JOIN cars car ON car.id = tb.car_id';
$params = [];
$where = [];

if ($search !== '') {
    $where[] = '(c.full_name LIKE :search OR car.name LIKE :search OR car.model LIKE :search)';
    $params[':search'] = '%' . $search . '%';
}

if ($statusFilter !== '') {
    $where[] = 'tb.status = :status';
    $params[':status'] = $statusFilter;
}

if ($where) {
    $query .= ' WHERE ' . implode(' AND ', $where);
}

$query .= ' ORDER BY tb.booking_date DESC, tb.booking_time DESC';
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$bookings = $stmt->fetchAll();

if ($editId > 0) {
    $editBooking = $pdo->prepare('SELECT * FROM test_drive_bookings WHERE id = :id');
    $editBooking->execute([':id' => $editId]);
    $editBooking = $editBooking->fetch();
}

include __DIR__ . '/includes/header.php';
?>

<div class="panel">
    <div class="panel-header">
        <div>
            <h2>Test Drives Before Purchase</h2>
            <p class="panel-kicker">Help customers experience a vehicle before completing their purchase.</p>
        </div>
        <button type="button" class="primary-btn" data-modal-target="booking-modal">Schedule Test Drive</button>
    </div>

    <form method="get" class="toolbar">
        <div class="search-box">
            <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search customer or car">
        </div>
        <div class="filter-box">
            <select name="status">
                <option value="">All statuses</option>
                <option value="Pending" <?php echo $statusFilter === 'Pending' ? 'selected' : ''; ?>>Pending</option>
                <option value="Completed" <?php echo $statusFilter === 'Completed' ? 'selected' : ''; ?>>Completed</option>
                <option value="Cancelled" <?php echo $statusFilter === 'Cancelled' ? 'selected' : ''; ?>>Cancelled</option>
            </select>
        </div>
        <button type="submit" class="secondary-btn">Apply</button>
        <a href="bookings.php" class="ghost-btn">Reset</a>
    </form>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Thumb</th>
                    <th>Customer</th>
                    <th>Car</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Status</th>
                    <th>Notes</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($bookings): ?>
                    <?php foreach ($bookings as $booking): ?>
                        <tr>
                            <td><?php echo renderCarThumbnail($booking['image_url'] ?? '', $booking['car_name'], 100, 80); ?></td>
                            <td><?php echo htmlspecialchars($booking['customer_name']); ?></td>
                            <td><?php echo htmlspecialchars($booking['car_name']); ?></td>
                            <td><?php echo htmlspecialchars($booking['booking_date']); ?></td>
                            <td><?php echo htmlspecialchars($booking['booking_time']); ?></td>
                            <td><span class="badge <?php echo strtolower($booking['status']); ?>"><?php echo htmlspecialchars($booking['status']); ?></span></td>
                            <td><?php echo htmlspecialchars($booking['notes'] ?: 'None'); ?></td>
                            <td>
                                <div class="action-group">
                                    <a href="bookings.php?edit_id=<?php echo (int) $booking['id']; ?>" class="small-btn">Edit</a>
                                    <form method="post" style="display:inline;" onsubmit="return confirm('Delete this booking?')">
                                        <input type="hidden" name="action" value="delete_booking">
                                        <input type="hidden" name="id" value="<?php echo (int) $booking['id']; ?>">
                                        <button type="submit" class="small-btn danger">Delete</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" class="empty-state">No bookings found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div id="booking-modal" class="modal <?php echo $editId > 0 ? 'open' : ''; ?>">
    <div class="modal-card">
        <div class="modal-header">
            <h3><?php echo $editId > 0 ? 'Edit Booking' : 'Add Booking'; ?></h3>
            <button type="button" class="modal-close">×</button>
        </div>
        <form method="post">
            <div class="modal-body">
                <input type="hidden" name="action" value="save_booking">
                <input type="hidden" name="id" value="<?php echo htmlspecialchars((string) ($editBooking['id'] ?? '')); ?>">
                <div class="form-grid">
                    <div class="form-group">
                        <label for="customer_id">Customer</label>
                        <select id="customer_id" class="form-control" name="customer_id" required>
                            <option value="">Select customer</option>
                            <?php foreach ($customers as $customer): ?>
                                <option value="<?php echo (int) $customer['id']; ?>" <?php echo (($editBooking['customer_id'] ?? 0) == $customer['id']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($customer['full_name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="car_id">Car</label>
                        <select id="car_id" class="form-control" name="car_id" required>
                            <option value="">Select car</option>
                            <?php foreach ($cars as $car): ?>
                                <option value="<?php echo (int) $car['id']; ?>" <?php echo (($editBooking['car_id'] ?? 0) == $car['id']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($car['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="booking_date">Booking Date</label>
                        <input id="booking_date" type="date" class="form-control" name="booking_date" value="<?php echo htmlspecialchars($editBooking['booking_date'] ?? date('Y-m-d')); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="booking_time">Booking Time</label>
                        <input id="booking_time" type="time" class="form-control" name="booking_time" value="<?php echo htmlspecialchars($editBooking['booking_time'] ?? '09:00'); ?>" required>
                    </div>
                    <div class="form-group full">
                        <label for="status">Status</label>
                        <select id="status" class="form-control" name="status">
                            <option value="Pending" <?php echo (($editBooking['status'] ?? 'Pending') === 'Pending') ? 'selected' : ''; ?>>Pending</option>
                            <option value="Completed" <?php echo (($editBooking['status'] ?? 'Pending') === 'Completed') ? 'selected' : ''; ?>>Completed</option>
                            <option value="Cancelled" <?php echo (($editBooking['status'] ?? 'Pending') === 'Cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                        </select>
                    </div>
                    <div class="form-group full">
                        <label for="notes">Notes</label>
                        <textarea id="notes" class="form-textarea" name="notes" rows="4"><?php echo htmlspecialchars($editBooking['notes'] ?? ''); ?></textarea>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="ghost-btn modal-close">Cancel</button>
                <button type="submit" class="primary-btn"><?php echo $editId > 0 ? 'Update Booking' : 'Add Booking'; ?></button>
            </div>
        </form>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
