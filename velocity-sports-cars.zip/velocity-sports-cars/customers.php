<?php
require __DIR__ . '/includes/db.php';

$pageTitle = 'Customer & Sales Records';
$pdo = getDatabaseConnection();

$search = trim($_GET['search'] ?? '');
$customerEditId = isset($_GET['edit_customer_id']) ? (int) $_GET['edit_customer_id'] : 0;
$saleEditId = isset($_GET['edit_sale_id']) ? (int) $_GET['edit_sale_id'] : 0;
$newSaleCarId = isset($_GET['new_sale_car_id']) ? (int) $_GET['new_sale_car_id'] : 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'save_customer') {
        $id = (int) ($_POST['id'] ?? 0);
        $fullName = trim($_POST['full_name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $city = trim($_POST['city'] ?? '');
        $preferredModel = trim($_POST['preferred_model'] ?? '');

        if ($fullName === '' || $email === '' || $phone === '' || $city === '') {
            setFlash('Please complete all required customer information.', 'error');
            redirect('customers.php');
        }

        if ($id > 0) {
            $stmt = $pdo->prepare('UPDATE customers SET full_name = :full_name, email = :email, phone = :phone, city = :city, preferred_model = :preferred_model WHERE id = :id');
            $stmt->execute([
                ':full_name' => $fullName,
                ':email' => $email,
                ':phone' => $phone,
                ':city' => $city,
                ':preferred_model' => $preferredModel,
                ':id' => $id,
            ]);
            setFlash('Customer updated successfully.');
        } else {
            $stmt = $pdo->prepare('INSERT INTO customers (full_name, email, phone, city, preferred_model) VALUES (:full_name, :email, :phone, :city, :preferred_model)');
            $stmt->execute([
                ':full_name' => $fullName,
                ':email' => $email,
                ':phone' => $phone,
                ':city' => $city,
                ':preferred_model' => $preferredModel,
            ]);
            setFlash('Customer added successfully.');
        }

        redirect('customers.php');
    }

    if ($action === 'delete_customer') {
        $id = (int) ($_POST['id'] ?? 0);
        if ($id > 0) {
            $pdo->prepare('DELETE FROM customers WHERE id = :id')->execute([':id' => $id]);
            setFlash('Customer deleted successfully.');
        }
        redirect('customers.php');
    }

    if ($action === 'save_sale') {
        $id = (int) ($_POST['id'] ?? 0);
        $customerId = (int) ($_POST['customer_id'] ?? 0);
        $carId = (int) ($_POST['car_id'] ?? 0);
        $saleDate = $_POST['sale_date'] ?? date('Y-m-d');
        $saleAmount = (float) ($_POST['sale_amount'] ?? 0);
        $paymentMethod = trim($_POST['payment_method'] ?? '');
        $status = $_POST['status'] ?? 'Paid';
        $notes = trim($_POST['notes'] ?? '');

        if ($customerId <= 0 || $carId <= 0 || $saleAmount <= 0 || $paymentMethod === '') {
            setFlash('Please complete all required sales information.', 'error');
            redirect('customers.php');
        }

        $previousCarId = 0;
        if ($id > 0) {
            $previousSale = $pdo->prepare('SELECT car_id FROM sales_transactions WHERE id = :id');
            $previousSale->execute([':id' => $id]);
            $previousCarId = (int) $previousSale->fetchColumn();
        }

        $syncCarStatus = static function (int $syncCarId, int $excludedSaleId) use ($pdo): void {
            $statusQuery = $pdo->prepare("SELECT SUM(status = 'Paid') AS paid_count, SUM(status = 'Pending') AS pending_count FROM sales_transactions WHERE car_id = :car_id AND id <> :sale_id");
            $statusQuery->execute([':car_id' => $syncCarId, ':sale_id' => $excludedSaleId]);
            $saleStatuses = $statusQuery->fetch();
            $carStatus = ((int) ($saleStatuses['paid_count'] ?? 0) > 0) ? 'Sold' : (((int) ($saleStatuses['pending_count'] ?? 0) > 0) ? 'Reserved' : 'Available');
            $pdo->prepare('UPDATE cars SET status = :status WHERE id = :id')->execute([':status' => $carStatus, ':id' => $syncCarId]);
        };

        $pdo->beginTransaction();
        try {
            if ($id > 0) {
                $stmt = $pdo->prepare('UPDATE sales_transactions SET customer_id = :customer_id, car_id = :car_id, sale_date = :sale_date, sale_amount = :sale_amount, payment_method = :payment_method, status = :status, notes = :notes WHERE id = :id');
                $stmt->execute([
                    ':customer_id' => $customerId,
                    ':car_id' => $carId,
                    ':sale_date' => $saleDate,
                    ':sale_amount' => $saleAmount,
                    ':payment_method' => $paymentMethod,
                    ':status' => $status,
                    ':notes' => $notes,
                    ':id' => $id,
                ]);
                $saleId = $id;
                $message = 'Purchase record updated successfully.';
            } else {
                $stmt = $pdo->prepare('INSERT INTO sales_transactions (customer_id, car_id, sale_date, sale_amount, payment_method, status, notes) VALUES (:customer_id, :car_id, :sale_date, :sale_amount, :payment_method, :status, :notes)');
                $stmt->execute([
                    ':customer_id' => $customerId,
                    ':car_id' => $carId,
                    ':sale_date' => $saleDate,
                    ':sale_amount' => $saleAmount,
                    ':payment_method' => $paymentMethod,
                    ':status' => $status,
                    ':notes' => $notes,
                ]);
                $saleId = (int) $pdo->lastInsertId();
                $message = 'Purchase recorded successfully.';
            }

            if ($previousCarId > 0 && $previousCarId !== $carId) {
                $syncCarStatus($previousCarId, $saleId);
            }
            $syncCarStatus($carId, 0);
            $pdo->commit();
            setFlash($message);
        } catch (Throwable $exception) {
            $pdo->rollBack();
            setFlash('The purchase record could not be saved.', 'error');
        }

        redirect('customers.php');
    }

    if ($action === 'delete_sale') {
        $id = (int) ($_POST['id'] ?? 0);
        if ($id > 0) {
            $pdo->prepare('DELETE FROM sales_transactions WHERE id = :id')->execute([':id' => $id]);
            setFlash('Sales record deleted successfully.');
        }
        redirect('customers.php');
    }
}

$customers = $pdo->query('SELECT * FROM customers ORDER BY full_name ASC')->fetchAll();
$cars = $pdo->query('SELECT id, name FROM cars WHERE deleted_at IS NULL ORDER BY name ASC')->fetchAll();

if ($customerEditId > 0) {
    $editCustomer = $pdo->prepare('SELECT * FROM customers WHERE id = :id');
    $editCustomer->execute([':id' => $customerEditId]);
    $editCustomer = $editCustomer->fetch();
}

if ($saleEditId > 0) {
    $editSale = $pdo->prepare('SELECT * FROM sales_transactions WHERE id = :id');
    $editSale->execute([':id' => $saleEditId]);
    $editSale = $editSale->fetch();
}

$query = 'SELECT st.*, c.full_name AS customer_name, car.name AS car_name, car.image_url FROM sales_transactions st JOIN customers c ON c.id = st.customer_id JOIN cars car ON car.id = st.car_id';
$params = [];
if ($search !== '') {
    $query .= ' WHERE c.full_name LIKE :search OR car.name LIKE :search OR c.city LIKE :search';
    $params[':search'] = '%' . $search . '%';
}
$query .= ' ORDER BY st.sale_date DESC, st.id DESC';
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$sales = $stmt->fetchAll();

include __DIR__ . '/includes/header.php';
?>

<div class="panel">
    <div class="panel-header">
        <div>
            <h2>Customers &amp; Purchase Records</h2>
            <p class="panel-kicker">Manage customers from test-drive interest through completed vehicle purchases.</p>
        </div>
        <button type="button" class="primary-btn" data-modal-target="customer-modal">Add Customer</button>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>City</th>
                    <th>Preferred Model</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($customers): ?>
                    <?php foreach ($customers as $customer): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($customer['full_name']); ?></td>
                            <td><?php echo htmlspecialchars($customer['email']); ?></td>
                            <td><?php echo htmlspecialchars($customer['phone']); ?></td>
                            <td><?php echo htmlspecialchars($customer['city']); ?></td>
                            <td><?php echo htmlspecialchars($customer['preferred_model'] ?: 'Not specified'); ?></td>
                            <td>
                                <div class="action-group">
                                    <a href="customers.php?edit_customer_id=<?php echo (int) $customer['id']; ?>" class="small-btn">Edit</a>
                                    <form method="post" style="display:inline;" onsubmit="return confirm('Delete this customer?')">
                                        <input type="hidden" name="action" value="delete_customer">
                                        <input type="hidden" name="id" value="<?php echo (int) $customer['id']; ?>">
                                        <button type="submit" class="small-btn danger">Delete</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" class="empty-state">No customers found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="panel" style="margin-top: 28px;">
    <div class="panel-header">
        <div>
            <h2>Actual Car Purchases</h2>
            <p class="panel-kicker">Track paid, pending, and refunded sales transactions.</p>
        </div>
        <button type="button" class="primary-btn" data-modal-target="sale-modal">Record Purchase</button>
    </div>

    <form method="get" class="toolbar">
        <div class="search-box">
            <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search customer, car, or city">
        </div>
        <button type="submit" class="secondary-btn">Apply</button>
        <a href="customers.php" class="ghost-btn">Reset</a>
    </form>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Thumb</th>
                    <th>Customer</th>
                    <th>Car</th>
                    <th>Date</th>
                    <th>Amount</th>
                    <th>Payment</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($sales): ?>
                    <?php foreach ($sales as $sale): ?>
                        <tr>
                            <td><?php echo renderCarThumbnail($sale['image_url'] ?? '', $sale['car_name'], 100, 80); ?></td>
                            <td><?php echo htmlspecialchars($sale['customer_name']); ?></td>
                            <td><?php echo htmlspecialchars($sale['car_name']); ?></td>
                            <td><?php echo htmlspecialchars($sale['sale_date']); ?></td>
                            <td><?php echo formatCurrency((float) $sale['sale_amount']); ?></td>
                            <td><?php echo htmlspecialchars($sale['payment_method']); ?></td>
                            <td><span class="badge <?php echo strtolower($sale['status']); ?>"><?php echo htmlspecialchars($sale['status']); ?></span></td>
                            <td>
                                <div class="action-group">
                                    <a href="customers.php?edit_sale_id=<?php echo (int) $sale['id']; ?>" class="small-btn">Edit</a>
                                    <form method="post" style="display:inline;" onsubmit="return confirm('Delete this sales record?')">
                                        <input type="hidden" name="action" value="delete_sale">
                                        <input type="hidden" name="id" value="<?php echo (int) $sale['id']; ?>">
                                        <button type="submit" class="small-btn danger">Delete</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" class="empty-state">No sales records found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div id="customer-modal" class="modal <?php echo $customerEditId > 0 ? 'open' : ''; ?>">
    <div class="modal-card">
        <div class="modal-header">
            <h3><?php echo $customerEditId > 0 ? 'Edit Customer' : 'Add Customer'; ?></h3>
            <button type="button" class="modal-close">×</button>
        </div>
        <form method="post">
            <div class="modal-body">
                <input type="hidden" name="action" value="save_customer">
                <input type="hidden" name="id" value="<?php echo htmlspecialchars((string) ($editCustomer['id'] ?? '')); ?>">
                <div class="form-grid">
                    <div class="form-group">
                        <label for="full_name">Full Name</label>
                        <input id="full_name" type="text" class="form-control" name="full_name" value="<?php echo htmlspecialchars($editCustomer['full_name'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input id="email" type="email" class="form-control" name="email" value="<?php echo htmlspecialchars($editCustomer['email'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="phone">Phone</label>
                        <input id="phone" type="text" class="form-control" name="phone" value="<?php echo htmlspecialchars($editCustomer['phone'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="city">City</label>
                        <input id="city" type="text" class="form-control" name="city" value="<?php echo htmlspecialchars($editCustomer['city'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group full">
                        <label for="preferred_model">Preferred Model</label>
                        <input id="preferred_model" type="text" class="form-control" name="preferred_model" value="<?php echo htmlspecialchars($editCustomer['preferred_model'] ?? ''); ?>">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="ghost-btn modal-close">Cancel</button>
                <button type="submit" class="primary-btn"><?php echo $customerEditId > 0 ? 'Update Customer' : 'Add Customer'; ?></button>
            </div>
        </form>
    </div>
</div>

<div id="sale-modal" class="modal <?php echo ($saleEditId > 0 || $newSaleCarId > 0) ? 'open' : ''; ?>">
    <div class="modal-card">
        <div class="modal-header">
            <h3><?php echo $saleEditId > 0 ? 'Edit Purchase' : 'Record Vehicle Purchase'; ?></h3>
            <button type="button" class="modal-close">×</button>
        </div>
        <form method="post">
            <div class="modal-body">
                <input type="hidden" name="action" value="save_sale">
                <input type="hidden" name="id" value="<?php echo htmlspecialchars((string) ($editSale['id'] ?? '')); ?>">
                <div class="form-grid">
                    <div class="form-group">
                        <label for="customer_select">Customer</label>
                        <select id="customer_select" class="form-control" name="customer_id" required>
                            <option value="">Select customer</option>
                            <?php foreach ($customers as $customer): ?>
                                <option value="<?php echo (int) $customer['id']; ?>" <?php echo (($editSale['customer_id'] ?? 0) == $customer['id']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($customer['full_name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="sale_car_id">Car</label>
                        <select id="sale_car_id" class="form-control" name="car_id" required>
                            <option value="">Select car</option>
                            <?php foreach ($cars as $car): ?>
                                <option value="<?php echo (int) $car['id']; ?>" <?php echo (($editSale['car_id'] ?? $newSaleCarId) == $car['id']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($car['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="sale_date">Sale Date</label>
                        <input id="sale_date" type="date" class="form-control" name="sale_date" value="<?php echo htmlspecialchars($editSale['sale_date'] ?? date('Y-m-d')); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="sale_amount">Purchase Amount</label>
                        <input id="sale_amount" type="number" step="0.01" class="form-control" name="sale_amount" value="<?php echo htmlspecialchars((string) ($editSale['sale_amount'] ?? '')); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="payment_method">Payment Method</label>
                        <input id="payment_method" type="text" class="form-control" name="payment_method" value="<?php echo htmlspecialchars($editSale['payment_method'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="sale_status">Status</label>
                        <select id="sale_status" class="form-control" name="status">
                            <option value="Paid" <?php echo (($editSale['status'] ?? 'Paid') === 'Paid') ? 'selected' : ''; ?>>Paid</option>
                            <option value="Pending" <?php echo (($editSale['status'] ?? 'Paid') === 'Pending') ? 'selected' : ''; ?>>Pending</option>
                            <option value="Refunded" <?php echo (($editSale['status'] ?? 'Paid') === 'Refunded') ? 'selected' : ''; ?>>Refunded</option>
                        </select>
                    </div>
                    <div class="form-group full">
                        <label for="sale_notes">Notes</label>
                        <textarea id="sale_notes" class="form-textarea" name="notes" rows="3"><?php echo htmlspecialchars($editSale['notes'] ?? ''); ?></textarea>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="ghost-btn modal-close">Cancel</button>
                <button type="submit" class="primary-btn"><?php echo $saleEditId > 0 ? 'Update Purchase' : 'Record Purchase'; ?></button>
            </div>
        </form>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
