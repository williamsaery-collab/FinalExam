document.addEventListener('DOMContentLoaded', () => {
    const modalRoot = document.getElementById('modal-root');
    document.querySelectorAll('.modal').forEach((modal) => {
        modal.querySelectorAll('.modal-close').forEach((button) => button.addEventListener('click', () => modal.classList.remove('open')));
        modal.addEventListener('click', (event) => {
            if (event.target === modal) modal.classList.remove('open');
        });
    });

    document.querySelectorAll('[data-modal-target]').forEach((button) => {
        button.addEventListener('click', () => {
            const targetId = button.getAttribute('data-modal-target');
            const target = document.getElementById(targetId);
            if (target) {
                if (button.dataset.pictureId) {
                    document.getElementById('picture-car-id').value = button.dataset.pictureId;
                    const preview = document.getElementById('picture-preview');
                    preview.src = button.dataset.pictureSrc || '';
                    preview.dataset.original = button.dataset.pictureSrc || '';
                    const input = document.getElementById('picture-upload');
                    if (input) input.value = '';
                }
                if (button.dataset.restoreId) document.getElementById('restore-car-id').value = button.dataset.restoreId;
                target.classList.add('open');
            }
        });
    });

    const pictureUpload = document.getElementById('picture-upload');
    const picturePreview = document.getElementById('picture-preview');
    pictureUpload?.addEventListener('change', () => {
        const file = pictureUpload.files?.[0];
        if (file) picturePreview.src = URL.createObjectURL(file);
    });
    document.querySelectorAll('#picture-modal .modal-close').forEach((button) => button.addEventListener('click', () => {
        if (picturePreview?.dataset.original) picturePreview.src = picturePreview.dataset.original;
        if (pictureUpload) pictureUpload.value = '';
    }));

    const video = document.querySelector('.cinematic-video');
    const videoToggle = document.querySelector('[data-video-toggle]');
    video?.addEventListener('error', () => {
        video.classList.add('video-unavailable');
        if (videoToggle) videoToggle.hidden = true;
    });
    if (video) {
        video.muted = true;
        video.play().catch(() => { video.controls = true; });
    }
    videoToggle?.addEventListener('click', () => {
        video.muted = !video.muted;
        videoToggle.textContent = video.muted ? 'Unmute video' : 'Mute video';
        videoToggle.setAttribute('aria-pressed', String(!video.muted));
    });

    document.querySelectorAll('.confirm-delete').forEach((button) => {
        button.addEventListener('click', (event) => {
            const confirmed = window.confirm('Are you sure you want to delete this record?');
            if (!confirmed) {
                event.preventDefault();
            }
        });
    });

    const toast = document.querySelector('.toast');
    if (toast) {
        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transition = 'opacity 0.3s ease';
            setTimeout(() => toast.remove(), 350);
        }, 3000);
    }
});
