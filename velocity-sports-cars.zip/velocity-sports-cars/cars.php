<?php
require __DIR__ . '/includes/db.php';

$pageTitle = 'Sports Cars For Sale';
$pdo = getDatabaseConnection();

$search = trim($_GET['search'] ?? '');
$statusFilter = $_GET['status'] ?? '';
$editId = isset($_GET['edit_id']) ? (int) $_GET['edit_id'] : 0;
$viewId = isset($_GET['view_id']) ? (int) $_GET['view_id'] : 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'change_picture') {
        $id = (int) ($_POST['id'] ?? 0);
        $file = $_FILES['picture'] ?? null;
        $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
        if ($id < 1 || !$file || ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            setFlash('Choose a picture to upload.', 'error');
            redirect('cars.php');
        }
        if (($file['size'] ?? 0) > 5 * 1024 * 1024 || $file['size'] < 1) {
            setFlash('Picture files must be smaller than 5 MB.', 'error');
            redirect('cars.php');
        }
        $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
        if (!isset($allowed[$mime]) || @getimagesize($file['tmp_name']) === false) {
            setFlash('Use a valid JPG, PNG, or WebP image.', 'error');
            redirect('cars.php');
        }
        $filename = bin2hex(random_bytes(16)) . '.' . $allowed[$mime];
        $directory = __DIR__ . '/assets/images/cars/';
        if (!move_uploaded_file($file['tmp_name'], $directory . $filename)) {
            setFlash('The picture could not be saved. Please try again.', 'error');
            redirect('cars.php');
        }
        $stmt = $pdo->prepare('UPDATE cars SET image_url = :image_url WHERE id = :id AND deleted_at IS NULL');
        $stmt->execute([':image_url' => 'assets/images/cars/' . $filename, ':id' => $id]);
        if ($stmt->rowCount() < 1) {
            @unlink($directory . $filename);
            setFlash('The car was not found or its picture was unchanged.', 'error');
        } else {
            setFlash('Car picture updated successfully.');
        }
        redirect('cars.php');
    }

    if ($action === 'save_car') {
        $id = (int) ($_POST['id'] ?? 0);
        $name = trim($_POST['name'] ?? '');
        $brand = trim($_POST['brand'] ?? '');
        $model = trim($_POST['model'] ?? '');
        $year = (int) ($_POST['year'] ?? 0);
        $status = $_POST['status'] ?? 'Available';
        $imageUrl = trim($_POST['image_url'] ?? '');

        if ($name === '' || $brand === '' || $model === '' || $year <= 0) {
            setFlash('Please complete all required car details.', 'error');
            redirect('cars.php');
        }

        if ($imageUrl === '') {
            $imageMap = [
                'ferrari 488' => 'assets/images/cars/ferrari-488.jpg',
                'lamborghini huracán' => 'assets/images/cars/lamborghini-huracan.jpg',
                'porsche 911' => 'assets/images/cars/porsche-911GT3.jpg',
                'mclaren 720s' => 'assets/images/cars/mclaren-720s.jpg',
                'nissan gtr' => 'assets/images/cars/nissan-gtrSkyline.jpg',
            ];
            $imageUrl = $imageMap[strtolower($name)] ?? '';
        }

        if ($id > 0) {
            $stmt = $pdo->prepare('UPDATE cars SET name = :name, brand = :brand, model = :model, year = :year, status = :status, image_url = :image_url WHERE id = :id');
            $stmt->execute([
                ':name' => $name,
                ':brand' => $brand,
                ':model' => $model,
                ':year' => $year,
                ':status' => $status,
                ':image_url' => $imageUrl,
                ':id' => $id,
            ]);
            setFlash('Car updated successfully.');
        } else {
            $stmt = $pdo->prepare('INSERT INTO cars (name, brand, model, year, status, image_url) VALUES (:name, :brand, :model, :year, :status, :image_url)');
            $stmt->execute([
                ':name' => $name,
                ':brand' => $brand,
                ':model' => $model,
                ':year' => $year,
                ':status' => $status,
                ':image_url' => $imageUrl,
            ]);
            setFlash('Car added successfully.');
        }

        redirect('cars.php');
    }

    if ($action === 'delete_car') {
        $id = (int) ($_POST['id'] ?? 0);
        if ($id > 0) {
            $pdo->prepare('UPDATE cars SET deleted_at = NOW() WHERE id = :id AND deleted_at IS NULL')->execute([':id' => $id]);
            setFlash('Car moved to Deleted Items.');
        }
        redirect('cars.php');
    }
}

$query = 'SELECT c.*, p.price_amount AS price, s.horsepower, s.engine, s.transmission FROM cars c LEFT JOIN prices p ON p.id = (SELECT p2.id FROM prices p2 WHERE p2.car_id = c.id ORDER BY p2.price_date DESC, p2.id DESC LIMIT 1) LEFT JOIN specifications s ON s.car_id = c.id';
$params = [];
$where = ['c.deleted_at IS NULL'];

if ($search !== '') {
    $where[] = '(c.name LIKE :search OR c.brand LIKE :search OR c.model LIKE :search)';
    $params[':search'] = '%' . $search . '%';
}

if ($statusFilter !== '') {
    $where[] = 'c.status = :status';
    $params[':status'] = $statusFilter;
}

if ($where) {
    $query .= ' WHERE ' . implode(' AND ', $where);
}

$query .= ' ORDER BY c.id DESC';
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$cars = $stmt->fetchAll();

if ($editId > 0) {
    $editCar = $pdo->prepare('SELECT * FROM cars WHERE id = :id AND deleted_at IS NULL');
    $editCar->execute([':id' => $editId]);
    $editCar = $editCar->fetch();
}

if ($viewId > 0) {
    $detail = $pdo->prepare('SELECT c.*, s.horsepower, s.engine, s.drivetrain, s.transmission, p.price_amount AS price FROM cars c LEFT JOIN specifications s ON s.car_id = c.id LEFT JOIN prices p ON p.car_id = c.id WHERE c.id = :id AND c.deleted_at IS NULL ORDER BY p.id DESC LIMIT 1');
    $detail->execute([':id' => $viewId]);
    $detail = $detail->fetch();
}

include __DIR__ . '/includes/header.php';
?>

<div class="panel">
    <div class="panel-header">
        <div>
            <h2>Premium Sports Cars For Sale</h2>
            <p class="panel-kicker">Browse our showroom selection, compare specifications, and start a purchase.</p>
        </div>
        <button type="button" class="primary-btn" data-modal-target="car-modal">Add Vehicle</button>
    </div>

    <form method="get" class="toolbar">
        <div class="search-box">
            <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search cars, brands, or models">
        </div>
        <div class="filter-box">
            <select name="status">
                <option value="">All statuses</option>
                <option value="Available" <?php echo $statusFilter === 'Available' ? 'selected' : ''; ?>>Available</option>
                <option value="Reserved" <?php echo $statusFilter === 'Reserved' ? 'selected' : ''; ?>>Reserved</option>
                <option value="Sold" <?php echo $statusFilter === 'Sold' ? 'selected' : ''; ?>>Sold</option>
            </select>
        </div>
        <button type="submit" class="secondary-btn">Apply</button>
        <a href="cars.php" class="ghost-btn">Reset</a>
    </form>

    <div class="vehicle-grid">
        <?php if ($cars): ?>
            <?php foreach ($cars as $car): ?>
                <article class="vehicle-card">
                    <div class="vehicle-card-image">
                        <?php echo renderCarThumbnail($car['image_url'] ?? '', $car['name'], 640, 390); ?>
                        <span class="vehicle-year"><?php echo htmlspecialchars((string) $car['year']); ?></span>
                        <span class="badge <?php echo strtolower($car['status']); ?> vehicle-status"><?php echo htmlspecialchars($car['status']); ?></span>
                    </div>
                    <div class="vehicle-card-body">
                        <p class="vehicle-brand"><?php echo htmlspecialchars($car['brand']); ?> / <?php echo htmlspecialchars($car['model']); ?></p>
                        <h3><?php echo htmlspecialchars($car['name']); ?></h3>
                        <p class="vehicle-description">A precision-built performance vehicle with an unmistakable road presence.</p>
                        <div class="vehicle-spec-row">
                            <span><strong><?php echo htmlspecialchars((string) ($car['horsepower'] ?? 'N/A')); ?></strong> HP</span>
                            <span><?php echo htmlspecialchars($car['engine'] ?? 'Specs pending'); ?></span>
                        </div>
                        <div class="vehicle-card-footer">
                            <div><small>Selling price</small><strong><?php echo formatCurrency((float) ($car['price'] ?? 0)); ?></strong></div>
                            <a href="cars.php?view_id=<?php echo (int) $car['id']; ?>" class="card-arrow">View details <span>↗</span></a>
                        </div>
                        <div class="vehicle-admin-actions">
                            <?php if ($car['status'] !== 'Sold'): ?><a href="customers.php?new_sale_car_id=<?php echo (int) $car['id']; ?>" class="small-btn primary">Start Purchase</a><?php endif; ?>
                            <a href="cars.php?edit_id=<?php echo (int) $car['id']; ?>" class="small-btn">Edit</a>
                            <button type="button" class="small-btn" data-picture-id="<?php echo (int) $car['id']; ?>" data-picture-src="<?php echo htmlspecialchars(getCarImagePath($car['image_url'] ?? '', $car['name']) ?? '', ENT_QUOTES); ?>" data-modal-target="picture-modal">Change Picture</button>
                            <form method="post" onsubmit="return confirm('Move this car to Deleted Items?')"><input type="hidden" name="action" value="delete_car"><input type="hidden" name="id" value="<?php echo (int) $car['id']; ?>"><button type="submit" class="small-btn danger">Delete</button></form>
                        </div>
                    </div>
                </article>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="empty-state">No cars match your current filters.</div>
        <?php endif; ?>
    </div>
</div>

<?php if (!empty($detail)): ?>
    <div class="detail-card">
        <p class="section-index">Vehicle profile</p><h3>Car Details</h3>
        <div class="detail-layout">
            <div class="detail-thumb"><?php echo renderCarThumbnail($detail['image_url'] ?? '', $detail['name'], 100, 100); ?></div>
            <div class="form-grid" style="flex: 1;">
                <div class="form-group"><label>Car</label><div><?php echo htmlspecialchars($detail['name']); ?></div></div>
                <div class="form-group"><label>Brand</label><div><?php echo htmlspecialchars($detail['brand']); ?></div></div>
                <div class="form-group"><label>Model</label><div><?php echo htmlspecialchars($detail['model']); ?></div></div>
                <div class="form-group"><label>Year</label><div><?php echo htmlspecialchars((string) $detail['year']); ?></div></div>
                <div class="form-group"><label>Status</label><div><?php echo htmlspecialchars($detail['status']); ?></div></div>
                <div class="form-group"><label>Selling Price</label><div><?php echo formatCurrency((float) ($detail['price'] ?? 0)); ?></div></div>
                <div class="form-group"><label>Horsepower</label><div><?php echo htmlspecialchars((string) ($detail['horsepower'] ?? 'N/A')); ?></div></div>
                <div class="form-group"><label>Engine</label><div><?php echo htmlspecialchars((string) ($detail['engine'] ?? 'N/A')); ?></div></div>
                <div class="form-group"><label>Transmission</label><div><?php echo htmlspecialchars((string) ($detail['transmission'] ?? 'N/A')); ?></div></div>
                <div class="form-group"><label>Drivetrain</label><div><?php echo htmlspecialchars((string) ($detail['drivetrain'] ?? 'N/A')); ?></div></div>
            </div>
            <div class="detail-actions">
                <a href="bookings.php" class="primary-btn">Book Test Drive</a>
                <?php if ($detail['status'] !== 'Sold'): ?><a href="customers.php?new_sale_car_id=<?php echo (int) $detail['id']; ?>" class="secondary-btn">Start Purchase</a><?php endif; ?>
            </div>
        </div>
    </div>
<?php endif; ?>

<div id="car-modal" class="modal <?php echo $editId > 0 ? 'open' : ''; ?>">
    <div class="modal-card">
        <div class="modal-header">
            <h3><?php echo $editId > 0 ? 'Edit Car' : 'Add Car'; ?></h3>
            <button type="button" class="modal-close">×</button>
        </div>
        <form method="post">
            <div class="modal-body">
                <input type="hidden" name="action" value="save_car">
                <input type="hidden" name="id" value="<?php echo htmlspecialchars((string) ($editCar['id'] ?? '')); ?>">
                <div class="form-grid">
                    <div class="form-group">
                        <label for="name">Car Name</label>
                        <input id="name" class="form-control" type="text" name="name" value="<?php echo htmlspecialchars($editCar['name'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="brand">Brand</label>
                        <input id="brand" class="form-control" type="text" name="brand" value="<?php echo htmlspecialchars($editCar['brand'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="model">Model</label>
                        <input id="model" class="form-control" type="text" name="model" value="<?php echo htmlspecialchars($editCar['model'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="year">Year</label>
                        <input id="year" class="form-control" type="number" name="year" min="2000" max="2035" value="<?php echo htmlspecialchars((string) ($editCar['year'] ?? '')); ?>" required>
                    </div>
                    <div class="form-group full">
                        <label for="image_url">Image Path</label>
                        <input id="image_url" class="form-control" type="text" name="image_url" value="<?php echo htmlspecialchars($editCar['image_url'] ?? ''); ?>" placeholder="assets/images/cars/ferrari-488.jpg">
                    </div>
                    <div class="form-group full">
                        <label for="status">Status</label>
                        <select id="status" class="form-control" name="status">
                            <option value="Available" <?php echo (($editCar['status'] ?? 'Available') === 'Available') ? 'selected' : ''; ?>>Available</option>
                            <option value="Reserved" <?php echo (($editCar['status'] ?? 'Available') === 'Reserved') ? 'selected' : ''; ?>>Reserved</option>
                            <option value="Sold" <?php echo (($editCar['status'] ?? 'Available') === 'Sold') ? 'selected' : ''; ?>>Sold</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="ghost-btn modal-close">Cancel</button>
                <button type="submit" class="primary-btn"><?php echo $editId > 0 ? 'Update Car' : 'Add Car'; ?></button>
            </div>
        </form>
    </div>
</div>

<div id="picture-modal" class="modal">
    <div class="modal-card">
        <div class="modal-header"><h3>Change Car Picture</h3><button type="button" class="modal-close" aria-label="Close">×</button></div>
        <form method="post" enctype="multipart/form-data" id="picture-form">
            <div class="modal-body">
                <input type="hidden" name="action" value="change_picture">
                <input type="hidden" name="id" id="picture-car-id" value="">
                <div class="picture-preview-wrap"><img id="picture-preview" src="" alt="Current car picture preview"></div>
                <div class="form-group"><label for="picture-upload">Upload New Picture (JPG, PNG, WebP; up to 5 MB)</label><input class="form-control" type="file" name="picture" id="picture-upload" accept="image/jpeg,image/png,image/webp" required></div>
            </div>
            <div class="modal-footer"><button type="button" class="ghost-btn modal-close">Cancel</button><button type="submit" class="primary-btn">Save Picture</button></div>
        </form>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
