<?php
require __DIR__ . '/includes/db.php';
$pageTitle = 'About Us';
include __DIR__ . '/includes/header.php';
?>
<section class="about-hero">
    <img src="assets/images/logo.png" alt="Velocity Sports Cars logo" class="about-logo">
    <p class="hero-kicker">A student project by Ria Jane A. Balacuit</p>
    <h2>About Velocity<br><em>Sports Cars</em></h2>
    <p>Velocity Sports Cars is a sports-car dealership website created to present exciting vehicles in a stylish, organized, and accessible way. This student project brings together car collections, specifications, pricing, test-drive bookings, and customer and sales records in one system.</p>
</section>
<section class="about-grid">
    <article class="about-card"><p class="section-index">01 / Purpose</p><h2>Our Purpose</h2><p>Our goal is to let users explore sports cars, review their features and prices, and access relevant dealership information through a convenient website.</p></article>
    <article class="about-card about-vision"><p class="section-index">02 / Vision</p><h2>Our Vision</h2><p>To create an engaging online sports-car experience that combines striking automotive presentation with organized information and useful digital functionality.</p></article>
</section>
<section class="about-offers"><div class="panel-header"><div><p class="section-index">03 / Explore</p><h2>What We Offer</h2></div></div><div class="about-offer-grid">
    <article><span>01</span><h3>Sports Car Collection</h3><p>Explore the cars in the showroom.</p></article>
    <article><span>02</span><h3>Detailed Specifications</h3><p>Review vehicle performance and features.</p></article>
    <article><span>03</span><h3>Car Pricing and Availability</h3><p>See current pricing and vehicle status.</p></article>
    <article><span>04</span><h3>Test-Drive Booking</h3><p>Record and manage test-drive bookings.</p></article>
    <article><span>05</span><h3>Customer and Sales Records</h3><p>Keep customer and transaction details organized.</p></article>
    <article><span>06</span><h3>Picture Updates and Restoration</h3><p>Update car images and restore cars from Deleted Items.</p></article>
</div></section>
<section class="creator-card"><div class="creator-photo"><img src="assets/images/profile.png" alt="Portrait of Ria Jane A. Balacuit"></div><div><p class="section-index">04 / The Creator</p><h2>Ria Jane A. Balacuit</h2><p>I am the student developer behind this project. I chose sports cars because I love them and wanted to create a website based on something that genuinely interests me.</p><a href="index.php" class="small-btn">Back to my portfolio</a></div></section>
<?php include __DIR__ . '/includes/footer.php'; ?>
