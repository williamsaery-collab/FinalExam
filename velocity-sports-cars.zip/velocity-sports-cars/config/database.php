<?php

define('DB_HOST', 'localhost');
define('DB_NAME', 'velocity_sports_cars');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');
