<?php
require __DIR__ . '/includes/db.php';

$pageTitle = 'Car Specifications';
$pdo = getDatabaseConnection();

$search = trim($_GET['search'] ?? '');
$carFilter = $_GET['car_id'] ?? '';
$editId = isset($_GET['edit_id']) ? (int) $_GET['edit_id'] : 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'save_specification') {
        $id = (int) ($_POST['id'] ?? 0);
        $carId = (int) ($_POST['car_id'] ?? 0);
        $horsepower = (int) ($_POST['horsepower'] ?? 0);
        $torque = (int) ($_POST['torque'] ?? 0);
        $topSpeed = (int) ($_POST['top_speed_kmh'] ?? 0);
        $acceleration = (float) ($_POST['acceleration_0_100'] ?? 0);
        $drivetrain = trim($_POST['drivetrain'] ?? '');
        $transmission = trim($_POST['transmission'] ?? '');
        $engine = trim($_POST['engine'] ?? '');
        $fuelType = trim($_POST['fuel_type'] ?? '');
        $color = trim($_POST['color'] ?? '');

        if ($carId <= 0 || $horsepower <= 0 || $drivetrain === '' || $transmission === '' || $engine === '' || $fuelType === '' || $color === '') {
            setFlash('Please complete the specification form.', 'error');
            redirect('specifications.php');
        }

        if ($id > 0) {
            $stmt = $pdo->prepare('UPDATE specifications SET car_id = :car_id, horsepower = :horsepower, torque = :torque, top_speed_kmh = :top_speed_kmh, acceleration_0_100 = :acceleration_0_100, drivetrain = :drivetrain, transmission = :transmission, engine = :engine, fuel_type = :fuel_type, color = :color WHERE id = :id');
            $stmt->execute([
                ':car_id' => $carId,
                ':horsepower' => $horsepower,
                ':torque' => $torque,
                ':top_speed_kmh' => $topSpeed,
                ':acceleration_0_100' => $acceleration,
                ':drivetrain' => $drivetrain,
                ':transmission' => $transmission,
                ':engine' => $engine,
                ':fuel_type' => $fuelType,
                ':color' => $color,
                ':id' => $id,
            ]);
            setFlash('Specification updated successfully.');
        } else {
            $stmt = $pdo->prepare('INSERT INTO specifications (car_id, horsepower, torque, top_speed_kmh, acceleration_0_100, drivetrain, transmission, engine, fuel_type, color) VALUES (:car_id, :horsepower, :torque, :top_speed_kmh, :acceleration_0_100, :drivetrain, :transmission, :engine, :fuel_type, :color)');
            $stmt->execute([
                ':car_id' => $carId,
                ':horsepower' => $horsepower,
                ':torque' => $torque,
                ':top_speed_kmh' => $topSpeed,
                ':acceleration_0_100' => $acceleration,
                ':drivetrain' => $drivetrain,
                ':transmission' => $transmission,
                ':engine' => $engine,
                ':fuel_type' => $fuelType,
                ':color' => $color,
            ]);
            setFlash('Specification added successfully.');
        }

        redirect('specifications.php');
    }

    if ($action === 'delete_specification') {
        $id = (int) ($_POST['id'] ?? 0);
        if ($id > 0) {
            $pdo->prepare('DELETE FROM specifications WHERE id = :id')->execute([':id' => $id]);
            setFlash('Specification deleted successfully.');
        }
        redirect('specifications.php');
    }
}

$cars = $pdo->query('SELECT id, name FROM cars WHERE deleted_at IS NULL ORDER BY name ASC')->fetchAll();

$query = 'SELECT s.*, c.name AS car_name, c.image_url FROM specifications s JOIN cars c ON c.id = s.car_id';
$params = [];
$where = [];

if ($search !== '') {
    $where[] = '(c.name LIKE :search OR s.engine LIKE :search OR s.drivetrain LIKE :search)';
    $params[':search'] = '%' . $search . '%';
}

if ($carFilter !== '') {
    $where[] = 's.car_id = :car_id';
    $params[':car_id'] = (int) $carFilter;
}

if ($where) {
    $query .= ' WHERE ' . implode(' AND ', $where);
}

$query .= ' ORDER BY c.name ASC';
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$specs = $stmt->fetchAll();

if ($editId > 0) {
    $editSpec = $pdo->prepare('SELECT * FROM specifications WHERE id = :id');
    $editSpec->execute([':id' => $editId]);
    $editSpec = $editSpec->fetch();
}

include __DIR__ . '/includes/header.php';
?>

<div class="panel">
    <div class="panel-header">
        <h2>Performance Specs</h2>
        <button type="button" class="primary-btn" data-modal-target="spec-modal">Add Specification</button>
    </div>

    <form method="get" class="toolbar">
        <div class="search-box">
            <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search by car, engine, drivetrain">
        </div>
        <div class="filter-box">
            <select name="car_id">
                <option value="">All cars</option>
                <?php foreach ($cars as $car): ?>
                    <option value="<?php echo (int) $car['id']; ?>" <?php echo $carFilter == (string) $car['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($car['name']); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <button type="submit" class="secondary-btn">Apply</button>
        <a href="specifications.php" class="ghost-btn">Reset</a>
    </form>

    <div class="spec-grid">
        <?php if ($specs): ?>
            <?php foreach ($specs as $spec): ?>
                <article class="spec-card">
                    <div class="spec-card-image"><?php echo renderCarThumbnail($spec['image_url'] ?? '', $spec['car_name'], 600, 260); ?></div>
                    <div class="spec-card-body">
                        <p class="vehicle-brand">Performance profile</p>
                        <h3><?php echo htmlspecialchars($spec['car_name']); ?></h3>
                        <div class="spec-highlight"><strong><?php echo htmlspecialchars((string) $spec['horsepower']); ?></strong><span>HORSEPOWER</span></div>
                        <div class="spec-metrics">
                            <div><span>Engine</span><strong><?php echo htmlspecialchars($spec['engine']); ?></strong></div>
                            <div><span>Transmission</span><strong><?php echo htmlspecialchars($spec['transmission']); ?></strong></div>
                            <div><span>Top speed</span><strong><?php echo htmlspecialchars((string) $spec['top_speed_kmh']); ?> km/h</strong></div>
                            <div><span>0—100 km/h</span><strong><?php echo htmlspecialchars((string) $spec['acceleration_0_100']); ?> s</strong></div>
                        </div>
                        <div class="action-group spec-actions">
                            <a href="specifications.php?edit_id=<?php echo (int) $spec['id']; ?>" class="small-btn">Edit</a>
                            <form method="post" onsubmit="return confirm('Delete this specification?')"><input type="hidden" name="action" value="delete_specification"><input type="hidden" name="id" value="<?php echo (int) $spec['id']; ?>"><button type="submit" class="small-btn danger">Delete</button></form>
                        </div>
                    </div>
                </article>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="empty-state">No specification records found.</div>
        <?php endif; ?>
    </div>
</div>

<div id="spec-modal" class="modal <?php echo $editId > 0 ? 'open' : ''; ?>">
    <div class="modal-card">
        <div class="modal-header">
            <h3><?php echo $editId > 0 ? 'Edit Specification' : 'Add Specification'; ?></h3>
            <button type="button" class="modal-close">×</button>
        </div>
        <form method="post">
            <div class="modal-body">
                <input type="hidden" name="action" value="save_specification">
                <input type="hidden" name="id" value="<?php echo htmlspecialchars((string) ($editSpec['id'] ?? '')); ?>">
                <div class="form-grid">
                    <div class="form-group full">
                        <label for="car_id">Car</label>
                        <select id="car_id" class="form-control" name="car_id" required>
                            <option value="">Select car</option>
                            <?php foreach ($cars as $car): ?>
                                <option value="<?php echo (int) $car['id']; ?>" <?php echo (($editSpec['car_id'] ?? 0) == $car['id']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($car['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="horsepower">Horsepower</label>
                        <input id="horsepower" type="number" class="form-control" name="horsepower" value="<?php echo htmlspecialchars((string) ($editSpec['horsepower'] ?? '')); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="torque">Torque</label>
                        <input id="torque" type="number" class="form-control" name="torque" value="<?php echo htmlspecialchars((string) ($editSpec['torque'] ?? '')); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="top_speed_kmh">Top Speed (km/h)</label>
                        <input id="top_speed_kmh" type="number" class="form-control" name="top_speed_kmh" value="<?php echo htmlspecialchars((string) ($editSpec['top_speed_kmh'] ?? '')); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="acceleration_0_100">0-100 (sec)</label>
                        <input id="acceleration_0_100" type="number" step="0.1" class="form-control" name="acceleration_0_100" value="<?php echo htmlspecialchars((string) ($editSpec['acceleration_0_100'] ?? '')); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="drivetrain">Drivetrain</label>
                        <input id="drivetrain" type="text" class="form-control" name="drivetrain" value="<?php echo htmlspecialchars($editSpec['drivetrain'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="transmission">Transmission</label>
                        <input id="transmission" type="text" class="form-control" name="transmission" value="<?php echo htmlspecialchars($editSpec['transmission'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="engine">Engine</label>
                        <input id="engine" type="text" class="form-control" name="engine" value="<?php echo htmlspecialchars($editSpec['engine'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="fuel_type">Fuel Type</label>
                        <input id="fuel_type" type="text" class="form-control" name="fuel_type" value="<?php echo htmlspecialchars($editSpec['fuel_type'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group full">
                        <label for="color">Color</label>
                        <input id="color" type="text" class="form-control" name="color" value="<?php echo htmlspecialchars($editSpec['color'] ?? ''); ?>" required>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="ghost-btn modal-close">Cancel</button>
                <button type="submit" class="primary-btn"><?php echo $editId > 0 ? 'Update Specification' : 'Add Specification'; ?></button>
            </div>
        </form>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
