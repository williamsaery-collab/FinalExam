<?php
require __DIR__ . '/includes/db.php';

try {
    $pdo = getDatabaseConnection();

    $stats = [
        'cars' => (int) $pdo->query('SELECT COUNT(*) FROM cars WHERE deleted_at IS NULL')->fetchColumn(),
        'available' => (int) $pdo->query("SELECT COUNT(*) FROM cars WHERE status = 'Available' AND deleted_at IS NULL")->fetchColumn(),
        'customers' => (int) $pdo->query('SELECT COUNT(*) FROM customers')->fetchColumn(),
        'pending_drives' => (int) $pdo->query("SELECT COUNT(*) FROM test_drive_bookings WHERE status = 'Pending'")->fetchColumn(),
        'completed_drives' => (int) $pdo->query("SELECT COUNT(*) FROM test_drive_bookings WHERE status = 'Completed'")->fetchColumn(),
        'sales' => (int) $pdo->query('SELECT COUNT(*) FROM sales_transactions')->fetchColumn(),
        'revenue' => (float) $pdo->query('SELECT COALESCE(SUM(sale_amount), 0) FROM sales_transactions')->fetchColumn(),
    ];

    $featuredCars = $pdo->query('SELECT c.*, p.price_amount AS price FROM cars c LEFT JOIN prices p ON p.id = (SELECT p2.id FROM prices p2 WHERE p2.car_id = c.id ORDER BY p2.price_date DESC, p2.id DESC LIMIT 1) WHERE c.deleted_at IS NULL ORDER BY c.id DESC LIMIT 4')->fetchAll();
    $recentSales = $pdo->query('SELECT st.*, c.full_name, car.name AS car_name FROM sales_transactions st JOIN customers c ON c.id = st.customer_id JOIN cars car ON car.id = st.car_id ORDER BY st.sale_date DESC LIMIT 5')->fetchAll();
    $recentBookings = $pdo->query('SELECT tb.*, c.full_name, car.name AS car_name FROM test_drive_bookings tb JOIN customers c ON c.id = tb.customer_id JOIN cars car ON car.id = tb.car_id ORDER BY tb.booking_date DESC, tb.booking_time DESC LIMIT 5')->fetchAll();
} catch (Throwable $exception) {
    $stats = [
        'cars' => 0,
        'available' => 0,
        'customers' => 0,
        'pending_drives' => 0,
        'completed_drives' => 0,
        'sales' => 0,
        'revenue' => 0,
    ];
    $featuredCars = [];
    $recentSales = [];
    $recentBookings = [];
}

$pageTitle = 'Dashboard';
include __DIR__ . '/includes/header.php';
?>

<?php
$heroVideoPath = 'assets/videos/hero-car.mp4';
$heroVideoFile = __DIR__ . '/' . $heroVideoPath;
$heroPoster = getCarImagePath($featuredCars[0]['image_url'] ?? null, $featuredCars[0]['name'] ?? null) ?? 'assets/images/cars/ferrari-488.jpg';
?>
<section class="cinematic-hero" style="--hero-poster: url('<?php echo htmlspecialchars($heroPoster, ENT_QUOTES); ?>')" aria-label="Velocity Sports Cars introduction">
    <?php if (is_file($heroVideoFile)): ?>
        <video class="cinematic-video" autoplay muted loop playsinline preload="metadata" poster="<?php echo htmlspecialchars($heroPoster, ENT_QUOTES); ?>">
            <source src="<?php echo htmlspecialchars($heroVideoPath, ENT_QUOTES); ?>" type="video/mp4">
            Your browser could not play the sports car video. <a href="cars.php">Explore the collection</a>.
        </video>
    <?php endif; ?>
    <div class="cinematic-overlay">
        <p class="hero-kicker">Velocity Sports Cars</p>
        <h2>Engineered to excite.<br><em>Built to inspire.</em></h2>
        <a href="cars.php" class="primary-btn">Explore Our Collection <span aria-hidden="true">&#8594;</span></a>
    </div>
    <?php if (is_file($heroVideoFile)): ?><button class="video-audio-toggle" type="button" data-video-toggle aria-pressed="false">Unmute video</button><?php endif; ?>
</section>

<section class="showroom-hero portfolio-hero">
    <div class="portfolio-intro">
        <img class="portfolio-logo" src="assets/images/logo.png" alt="Velocity Sports Cars logo">
        <p class="hero-kicker">My Portfolio / Sports Cars</p>
        <h2>Welcome to<br><em>My Project</em></h2>
        <h3 class="portfolio-name">Ria Jane A. Balacuit</h3>
        <p class="portfolio-address">Butoc, Mandangoa, Balingasag, Misamis Oriental, Philippines</p>
        <p>I created VELOCITY SPORTS CARS because I am interested in sports cars and their design, performance, and engineering. This project brings that interest to life as an interactive showroom.</p>
        <div class="hero-actions">
            <a href="cars.php" class="primary-btn">Explore the Collection <span aria-hidden="true">&#8594;</span></a>
        </div>
    </div>
    <div class="portfolio-photo-frame">
        <img src="assets/images/profile.png" alt="Portrait of Ria Jane A. Balacuit" class="portfolio-photo">
        <span class="photo-accent" aria-hidden="true"></span>
    </div>
</section>

<section class="portfolio-story" aria-label="About my project">
    <article><p class="section-index">01 / My first choice</p><h2>Why I chose sports cars</h2><p>I love sports cars and enjoy exploring their exciting designs, performance, and unique features. I wanted my project to be about something I personally enjoy, so I could build a functional and creative website around a topic that motivates me.</p></article>
    <article><p class="section-index">02 / My second choice</p><h2>A cake shop</h2><p>A cake-shop website was my other idea. I appreciate the creativity of cakes, but as I considered both topics I realized sports cars felt more exciting and personal to me. I chose the topic I would enjoy exploring and developing most.</p></article>
    <article><p class="section-index">03 / The change</p><h2>Why I changed to sports cars</h2><p>I changed my topic because sports cars inspired me more and gave me a chance to build a showroom experience around a personal interest.</p></article>
    <article><p class="section-index">04 / What it means to me</p><h2>Why I am proud of this project</h2><p>I am proud that the project turns an interest of mine into a working database website. It brings together a sports-car collection, specifications, pricing, bookings, and customer and sales records, with car picture uploads and Deleted Items restoration.</p></article>
    <article><p class="section-index">05 / The experience</p><h2>What makes this website a good choice</h2><p>The website brings the main showroom information and management tools together in a responsive experience. Users can explore cars, review their details, book a test drive, and manage records.</p></article>
    <article><p class="section-index">06 / What I learned</p><h2>What I learned developing this project</h2><p>I learned to connect PHP pages to a MySQL database, build forms and prepared queries, validate and save image uploads, and design responsive pages that organize real project records.</p></article>
</section>
<section class="stats-grid">
    <article class="stat-card">
        <div class="label">Showroom Cars</div>
        <span class="value"><?php echo $stats['cars']; ?></span>
        <div class="trend">Premium vehicles in the collection</div>
    </article>
    <article class="stat-card">
        <div class="label">Cars For Sale</div>
        <span class="value"><?php echo $stats['available']; ?></span>
        <div class="trend">Available for purchase</div>
    </article>
    <article class="stat-card">
        <div class="label">Total Customers</div>
        <span class="value"><?php echo $stats['customers']; ?></span>
        <div class="trend">Active client base</div>
    </article>
    <article class="stat-card">
        <div class="label">Pending Test Drives</div>
        <span class="value"><?php echo $stats['pending_drives']; ?></span>
        <div class="trend">Awaiting approval</div>
    </article>
    <article class="stat-card">
        <div class="label">Completed Drives</div>
        <span class="value"><?php echo $stats['completed_drives']; ?></span>
        <div class="trend">Customer experiences</div>
    </article>
    <article class="stat-card">
        <div class="label">Vehicle Purchases</div>
        <span class="value"><?php echo $stats['sales']; ?></span>
        <div class="trend">Recorded car sales</div>
    </article>
    <article class="stat-card">
        <div class="label">Total Revenue</div>
        <span class="value"><?php echo formatCurrency((float) $stats['revenue']); ?></span>
        <div class="trend">Across all sales</div>
    </article>
</section>

<div class="showroom-section">
    <div class="panel-header">
        <div>
            <p class="section-index">01 / The collection</p>
            <h2>Featured sports cars</h2>
            <p class="panel-kicker">A small selection of machines currently available through the showroom.</p>
        </div>
        <a href="cars.php" class="section-link">View all vehicles <span>↗</span></a>
    </div>
    <div class="featured-grid">
        <?php if ($featuredCars): ?>
            <?php foreach ($featuredCars as $car): ?>
                <article class="featured-card">
                    <div class="featured-image-wrap">
                        <?php echo renderCarThumbnail($car['image_url'] ?? '', $car['name'], 100, 100); ?>
                    </div>
                    <div class="featured-body">
                        <h3><?php echo htmlspecialchars($car['name']); ?></h3>
                        <div class="featured-price"><?php echo formatCurrency((float) ($car['price'] ?? 0)); ?></div>
                        <div class="featured-meta">
                            <span class="badge <?php echo strtolower($car['status']); ?>"><?php echo htmlspecialchars($car['status']); ?></span>
                        </div>
                        <div class="action-group">
                            <a href="cars.php?view_id=<?php echo (int) $car['id']; ?>" class="small-btn">View Details</a>
                            <?php if ($car['status'] !== 'Sold'): ?>
                                <a href="customers.php?new_sale_car_id=<?php echo (int) $car['id']; ?>" class="small-btn primary">Purchase</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </article>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="empty-state">No featured cars available.</div>
        <?php endif; ?>
    </div>
</div>

<div class="dashboard-columns">
<div class="panel dashboard-panel">
    <div class="panel-header">
        <h2>Recent Vehicle Purchases</h2>
    </div>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Customer</th>
                    <th>Car</th>
                    <th>Date</th>
                    <th>Amount</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($recentSales): ?>
                    <?php foreach ($recentSales as $sale): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($sale['full_name']); ?></td>
                            <td><?php echo htmlspecialchars($sale['car_name']); ?></td>
                            <td><?php echo htmlspecialchars($sale['sale_date']); ?></td>
                            <td><?php echo formatCurrency((float) $sale['sale_amount']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="4" class="empty-state">No recent sales found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="panel dashboard-panel">
    <div class="panel-header">
        <h2>Recent Test Drive Bookings</h2>
    </div>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Customer</th>
                    <th>Car</th>
                    <th>Date</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($recentBookings): ?>
                    <?php foreach ($recentBookings as $booking): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($booking['full_name']); ?></td>
                            <td><?php echo htmlspecialchars($booking['car_name']); ?></td>
                            <td><?php echo htmlspecialchars($booking['booking_date']); ?></td>
                            <td><span class="badge <?php echo strtolower($booking['status']); ?>"><?php echo htmlspecialchars($booking['status']); ?></span></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="4" class="empty-state">No recent bookings found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
