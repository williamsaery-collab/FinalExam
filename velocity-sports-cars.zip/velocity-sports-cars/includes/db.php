<?php
session_start();
require_once __DIR__ . '/../config/database.php';

function getDatabaseConnection(): PDO
{
    $dsn = sprintf('mysql:host=%s;dbname=%s;charset=%s', DB_HOST, DB_NAME, DB_CHARSET);
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ];

    try {
        return new PDO($dsn, DB_USER, DB_PASS, $options);
    } catch (PDOException $exception) {
        throw new PDOException('Database connection failed: ' . $exception->getMessage());
    }
}

function getCarImagePath(?string $imageUrl = null, ?string $carName = null): ?string
{
    $relativeDirectory = 'assets/images/cars/';
    $absoluteDirectory = __DIR__ . '/../' . $relativeDirectory;
    $normalized = trim(str_replace('\\', '/', (string) ($imageUrl ?? '')));
    $storedFilename = basename($normalized);
    if (preg_match('/^[a-zA-Z0-9._-]+\.(?:jpe?g|png|webp)$/i', $storedFilename)
        && is_file($absoluteDirectory . $storedFilename)
        && strtolower(dirname($normalized)) === 'assets/images/cars') {
        return $relativeDirectory . $storedFilename;
    }
    $jpgFiles = glob($absoluteDirectory . '*.jpg') ?: [];

    if ($jpgFiles === []) {
        return null;
    }

    $imageName = $normalized;

    foreach ($jpgFiles as $jpgFile) {
        if ($storedFilename !== '' && strcasecmp($storedFilename, basename($jpgFile)) === 0) {
            return $relativeDirectory . basename($jpgFile);
        }
    }

    // Older records may contain a different extension or only a filename.
    $storedStem = strtolower((string) pathinfo($storedFilename, PATHINFO_FILENAME));
    $storedStem = (string) preg_replace('/(?:\.jpg)+$/i', '', $storedStem);
    if ($storedStem !== '') {
        foreach ($jpgFiles as $jpgFile) {
            $jpgStem = strtolower((string) pathinfo($jpgFile, PATHINFO_FILENAME));
            if ($storedStem === $jpgStem || str_starts_with($jpgStem, $storedStem)) {
                return $relativeDirectory . basename($jpgFile);
            }
        }
    }

    if ($carName !== null && trim($carName) !== '') {
        $carTokens = preg_split('/[^a-z0-9]+/i', strtolower($carName), -1, PREG_SPLIT_NO_EMPTY);
        $bestMatch = null;
        $bestScore = 0;

        foreach ($jpgFiles as $jpgFile) {
            $jpgStem = strtolower((string) pathinfo($jpgFile, PATHINFO_FILENAME));
            $score = 0;
            foreach ($carTokens as $token) {
                if (strlen($token) >= 3 && str_contains($jpgStem, $token)) {
                    $score++;
                }
            }

            if ($score > $bestScore) {
                $bestScore = $score;
                $bestMatch = $jpgFile;
            }
        }

        if ($bestMatch !== null) {
            return $relativeDirectory . basename($bestMatch);
        }
    }

    return null;
}

function renderCarThumbnail(?string $imageUrl = null, string $alt = 'Car image', int $width = 100, int $height = 100): string
{
    $src = getCarImagePath($imageUrl, $alt);
    if ($src === null) {
        return '<div class="image-placeholder" role="img" aria-label="' . htmlspecialchars($alt, ENT_QUOTES, 'UTF-8') . ' image unavailable">Image unavailable</div>';
    }

    return '<img src="' . htmlspecialchars($src, ENT_QUOTES, 'UTF-8') . '" alt="' . htmlspecialchars($alt, ENT_QUOTES, 'UTF-8') . '" width="' . (int) $width . '" height="' . (int) $height . '" loading="lazy" class="car-thumbnail">';
}
function setFlash(string $message, string $type = 'success'): void
{
    $_SESSION['flash'] = [
        'message' => $message,
        'type' => $type,
    ];
}

function getFlash(): ?array
{
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }

    return null;
}

function formatCurrency(float $amount): string
{
    return '₱' . number_format($amount, 0, '.', ',');
}

function redirect(string $url): void
{
    header('Location: ' . $url);
    exit;
}

function ensureDatabaseExists(): void
{
    $pdo = new PDO('mysql:host=localhost;charset=utf8mb4', DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec('CREATE DATABASE IF NOT EXISTS ' . DB_NAME);
}
