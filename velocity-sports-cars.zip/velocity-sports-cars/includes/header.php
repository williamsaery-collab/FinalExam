<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle ?? 'Velocity Sports Cars'; ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@500;600;700&family=Manrope:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/styles.css?v=20261010-hero-restore">
</head>
<body>
    <div class="app-shell">
        <?php include __DIR__ . '/sidebar.php'; ?>
        <div class="main-panel">
            <header class="app-header">
                <div>
                    <p class="eyebrow">Velocity / Performance showroom</p>
                    <h1><?php echo $pageTitle ?? 'Dashboard'; ?></h1>
                </div>
                <div class="header-actions">
                    <a href="bookings.php" class="ghost-btn">Book a Test Drive</a>
                    <a href="cars.php" class="primary-btn">Explore Collection</a>
                </div>
            </header>
            <?php $flash = getFlash(); ?>
            <?php if ($flash): ?>
                <div class="toast <?php echo htmlspecialchars($flash['type']); ?>" role="alert">
                    <?php echo htmlspecialchars($flash['message']); ?>
                </div>
            <?php endif; ?>
