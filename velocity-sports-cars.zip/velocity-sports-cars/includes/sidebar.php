<aside class="sidebar">
    <div class="brand-block">
        <div class="logo-box">
            <img src="assets/images/logo.png" alt="Velocity Sports Cars logo" class="brand-logo">
        </div>
    </div>

    <nav class="sidebar-nav">
        <a href="index.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'index.php' ? 'active' : ''; ?>">
            <span>◉</span>
            Dashboard
        </a>
        <a href="cars.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'cars.php' ? 'active' : ''; ?>">
            <span>🏎️</span>
            Sports Car Collection
        </a>
        <a href="specifications.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'specifications.php' ? 'active' : ''; ?>">
            <span>⚙️</span>
            Car Specifications
        </a>
        <a href="prices.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'prices.php' ? 'active' : ''; ?>">
            <span>💰</span>
            Car Pricing
        </a>
        <a href="bookings.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'bookings.php' ? 'active' : ''; ?>">
            <span>📅</span>
            Test Drive Booking
        </a>
        <a href="customers.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'customers.php' ? 'active' : ''; ?>">
            <span>👥</span>
            Customer &amp; Sales Records
        </a>
        <a href="deleted.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'deleted.php' ? 'active' : ''; ?>">
            <span aria-hidden="true">&#128465;</span>
            Deleted Items
        </a>
        <a href="about.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'about.php' ? 'active' : ''; ?>">
            <span aria-hidden="true">&#9432;</span>
            About Us
        </a>
    </nav>
</aside>
