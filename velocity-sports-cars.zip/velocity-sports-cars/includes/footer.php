        </div>
    </div>

    <div id="modal-root"></div>
    <script src="assets/js/app.js?v=20261010-hero-restore"></script>
</body>
</html>
