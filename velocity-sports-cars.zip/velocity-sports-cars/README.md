# VELOCITY SPORTS CARS

A database-driven sports car showroom website built with PHP, MySQL, HTML, CSS, JavaScript, and PDO.

## Requirements satisfied
- Dashboard with real statistics
- Five main sections: cars, specifications, prices, bookings, customers/sales
- CRUD operations with prepared statements
- Search and filtering by key fields
- Premium dark luxury UI
- Responsive layout for XAMPP usage
- MySQL schema and sample data

## Local setup
1. Start Apache and MySQL in XAMPP.
2. Open phpMyAdmin and import `database/velocity_sports_cars.sql`.
3. Ensure the database is named `velocity_sports_cars`.
4. Visit the project folder in your browser, for example:
   http://localhost/velocity-sports-cars/

## Files
- `index.php` — dashboard
- `cars.php` — inventory management
- `specifications.php` — technical specs management
- `prices.php` — car pricing management
- `bookings.php` — test drive bookings management
- `customers.php` — customer and sales records
- `includes/db.php` — PDO connection and helper functions
- `includes/header.php`, `includes/sidebar.php`, `includes/footer.php` — reusable layout
- `assets/css/styles.css` — theme and layout styling
- `assets/js/app.js` — UI behavior and confirmation prompts

## Notes
The project uses the default XAMPP MySQL credentials:
- host: `127.0.0.1`
- username: `root`
- password: `''` (empty)

Before using the website, import the SQL file in phpMyAdmin to create the schema and sample data.
