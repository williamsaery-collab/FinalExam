# VELOCITY SPORTS CARS

This is my Fundamentals of Database final project.

Build a complete database-driven website called VELOCITY SPORTS CARS.

Use:
- PHP
- MySQL
- HTML
- CSS
- JavaScript
- XAMPP
- PHP PDO

The website must have a dashboard and these 5 sidebar sections:

1. Sports Car Collection
2. Car Specifications
3. Car Pricing
4. Test Drive Booking
5. Customer & Sales Records

Database name:
velocity_sports_cars

Tables:
- cars
- specifications
- prices
- customers
- test_drive_bookings
- sales_transactions

Use primary keys and foreign keys.

Relationships:
- cars 1:1 specifications
- cars 1:many prices
- cars 1:many test_drive_bookings
- customers 1:many test_drive_bookings
- cars 1:many sales_transactions
- customers 1:many sales_transactions

The system must have complete CRUD:
Create
Read
Update
Delete

Use MySQL with PHP PDO and prepared statements.

Dashboard must show real database statistics:
- Total Cars
- Available Cars
- Total Customers
- Pending Bookings
- Completed Bookings
- Total Sales
- Total Revenue

Cars:
- Ferrari 488
- Lamborghini Huracán
- Porsche 911
- McLaren 720S
- Nissan GT-R

Prices:
Ferrari 488 - ₱12,500,000
Lamborghini Huracán - ₱16,500,000
Porsche 911 - ₱10,500,000
McLaren 720S - ₱18,000,000
Nissan GT-R - ₱8,500,000

Each section must have:
- Search
- Filter
- Add
- Edit
- Delete
- View details

Use JOIN queries so related records show names instead of only IDs.

Design:
- Premium sports car theme
- Dark luxury interface
- Black/charcoal background
- White text
- Red/orange accents
- Modern cards
- Responsive sidebar
- Responsive tables
- Icons
- Animations
- Modal forms
- Toast notifications
- Confirmation dialogs
- Mobile responsive

Create:
- database SQL file
- PHP pages
- database connection
- reusable header/sidebar/navbar/footer
- CSS
- JavaScript
- sample database records
- README with installation instructions

IMPORTANT:
Inspect my existing workspace first.

Do not destroy working files unnecessarily.

Create and modify the actual files instead of only explaining code.

Make sure the final project works with XAMPP and phpMyAdmin.