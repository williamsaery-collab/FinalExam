<?php
require __DIR__ . '/includes/db.php';
$pageTitle = 'Deleted Items';
$pdo = getDatabaseConnection();
$restoreCar = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'restore_car') {
    $id = (int) ($_POST['id'] ?? 0);
    if ($id < 1) {
        setFlash('Select a valid car to restore.', 'error');
        redirect('deleted.php');
    }
    try {
        $stmt = $pdo->prepare('UPDATE cars SET deleted_at = NULL WHERE id = :id AND deleted_at IS NOT NULL');
        $stmt->execute([':id' => $id]);
        if ($stmt->rowCount() === 1) {
            setFlash('Car restored to the active collection.');
        } else {
            $check = $pdo->prepare('SELECT deleted_at FROM cars WHERE id = :id');
            $check->execute([':id' => $id]);
            $existingCar = $check->fetch();
            if (!$existingCar) {
                setFlash('That car record no longer exists. Refresh Deleted Items and try again.', 'error');
            } elseif ($existingCar['deleted_at'] === null) {
                setFlash('This car is already in the active collection.');
            } else {
                setFlash('The car is still marked as deleted, and restoration did not complete. Please try again.', 'error');
            }
        }
    } catch (Throwable $exception) {
        error_log('[Deleted Items restore] car_id=' . $id . ' ' . $exception->getMessage());
        setFlash('The car could not be restored because the database reported an error. Please try again.', 'error');
    }
    redirect('deleted.php');
}

$confirmRestoreId = (int) ($_GET['confirm_restore'] ?? 0);
if ($confirmRestoreId > 0) {
    $confirmStmt = $pdo->prepare('SELECT id, name FROM cars WHERE id = :id AND deleted_at IS NOT NULL');
    $confirmStmt->execute([':id' => $confirmRestoreId]);
    $restoreCar = $confirmStmt->fetch() ?: null;
}

$cars = $pdo->query('SELECT c.*, (SELECT p.price_amount FROM prices p WHERE p.car_id = c.id ORDER BY p.price_date DESC, p.id DESC LIMIT 1) AS price FROM cars c WHERE c.deleted_at IS NOT NULL ORDER BY c.deleted_at DESC')->fetchAll();
include __DIR__ . '/includes/header.php';
?>
<div class="panel">
    <div class="panel-header"><div><h2>Deleted sports cars</h2><p class="panel-kicker">Restore a car to return it to the active collection. Related records and images stay attached.</p></div></div>
    <div class="table-wrap"><table class="deleted-table">
        <thead><tr><th>ID</th><th>Name</th><th>Description</th><th>Price</th><th>Picture/Image</th><th>Action</th></tr></thead>
        <tbody>
        <?php if ($cars): foreach ($cars as $car): ?>
            <tr>
                <td><?php echo (int) $car['id']; ?></td>
                <td><?php echo htmlspecialchars($car['name']); ?></td>
                <td><?php echo htmlspecialchars($car['brand'] . ' ' . $car['model'] . ' (' . $car['year'] . ') · ' . $car['status']); ?></td>
                <td><?php echo formatCurrency((float) ($car['price'] ?? 0)); ?></td>
                <td><div class="deleted-thumb"><?php echo renderCarThumbnail($car['image_url'] ?? '', $car['name'], 120, 80); ?></div></td>
                <td><a class="small-btn primary" href="deleted.php?confirm_restore=<?php echo (int) $car['id']; ?>">Restore</a></td>
            </tr>
        <?php endforeach; else: ?><tr><td colspan="6" class="empty-state">There are no deleted cars.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
</div>
<div id="restore-modal" class="modal <?php echo $restoreCar ? 'open' : ''; ?>">
    <div class="modal-card"><div class="modal-header"><h3>Restore car</h3><button type="button" class="modal-close" aria-label="Close">×</button></div>
        <?php if ($restoreCar): ?><form method="post" id="restore-form"><div class="modal-body"><p>Do you want to restore this car to the active collection?</p><input type="hidden" name="action" value="restore_car"><input type="hidden" name="id" id="restore-car-id" value="<?php echo (int) $restoreCar['id']; ?>"></div>
            <div class="modal-footer"><button type="button" class="ghost-btn modal-close">Cancel</button><button type="submit" class="primary-btn">Restore</button></div>
        </form><?php endif; ?>
    </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
